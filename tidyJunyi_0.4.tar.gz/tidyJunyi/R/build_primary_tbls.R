#' build all tidy tbls
#' @param force create a new data table despite a previous table with a same name already exist
#' @return returns dplyr tbl object
#' @export

build_primary_tbls <- function(force = F){

  #info
  assign("usr_info", tbl_info_User(force = force), envir = .GlobalEnv)
  assign("cnt_info", tbl_info_Content(force = force), envir = .GlobalEnv)

  #log
  assign("asign_log", tbl_log_AssignMission(force = force), envir = .GlobalEnv)
  assign("do_log", tbl_log_DoingMission(force = force), envir = .GlobalEnv)
  assign("vprob_log", tbl_log_VideoProb(force = force), envir = .GlobalEnv)

  assign("ptmpt_log", tbl_log_ProbAttempt(force = force), envir = .GlobalEnv)
  assign("pquiz_log", tbl_log_ProbQuiz(force = force), envir = .GlobalEnv)
  assign("vplay_log", tbl_log_VideoPlayback(force = force), envir = .GlobalEnv)

  #relation
  assign("tscoach_rel", tbl_log_VideoProb(force = force), envir = .GlobalEnv)
  assign("tsclass_rel", tbl_log_VideoProb(force = force), envir = .GlobalEnv)
  assign("sscoach_rel", tbl_log_VideoProb(force = force), envir = .GlobalEnv)
  assign("ssclass_rel", tbl_log_VideoProb(force = force), envir = .GlobalEnv)
  assign("sameip_rel", tbl_log_VideoProb(force = force), envir = .GlobalEnv)
  assign("userid_rel", tbl_log_VideoProb(force = force), envir = .GlobalEnv)
  assign("pquiz_rel", tbl_log_VideoProb(force = force), envir = .GlobalEnv)
  assign("mission_cnt_rel", tbl_log_VideoProb(force = force), envir = .GlobalEnv)

}#end function





